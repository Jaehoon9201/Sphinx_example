.. sphinx_ex documentation master file, created by
   sphinx-quickstart on Sat Apr  9 00:04:22 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Sphinx_example
=====================================

.. automodule:: sphinx_example
   :members:
   :undoc-members:
   :show-inheritance:

   Fault diagnosis main
## title Name

Fault diagnosis main
-------------

.. automodule:: sphinx_example.__main__
   :members:

