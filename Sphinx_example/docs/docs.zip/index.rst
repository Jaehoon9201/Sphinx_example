.. sphinx_ex documentation master file, created by
   sphinx-quickstart on Sat Apr  9 00:04:22 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to sphinx_example's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   sphinx_example_main.rst
   sphinx_example_solver.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
